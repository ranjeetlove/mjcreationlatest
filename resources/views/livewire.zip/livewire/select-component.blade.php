<div class="col-md-6">
    <label for="" class="form-label">Brand Name</label>
    <div class="input-group">
        <select name="product_brandid" class="form-select" aria-label="Default select example">
            <option selected disabled>Open this select menu</option>
            @foreach ($product_brands as $data)
                <option wire:key="{{ $data->id }}" value="{{ $data->id }}">{{ ucwords($data->name) }}</option>
            @endforeach
        </select>
        <!-- Button to trigger modal -->
        <button type="button" style="color:white" class="btn btn-primary" data-bs-toggle="modal"
            data-bs-target="#exampleModal">
            Add New Brand Name
        </button>

        <!-- Modal -->
        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Add Option</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <!-- Form inside the modal -->


                        <div class="mb-3">
                            <label for="optionName" class="form-label">Option Name</label>
                            <input type="text" class="form-control" id="optionName" wire:model="optionName">
                        </div>
                        <div class="mb-3">
                            <label for="fileInput" class="form-label">Upload File</label>
                            <input type="file" class="form-control" id="fileInput" wire:model="file">
                        </div>
                        <button class="btn btn-primary" wire:click.prevent="addOption">Add</button>

                    </div>
                </div>
            </div>
        </div>

    </div>
</div>
