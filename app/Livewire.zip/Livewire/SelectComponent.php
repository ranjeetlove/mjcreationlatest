<?php

namespace App\Livewire;
use App\Models\Productbrand;
use Livewire\Component;
use Livewire\WithFileUploads;
use Illuminate\Validation\Rule;
use Livewire\Form;

class SelectComponent extends Component
{
    use WithFileUploads;
    // #[Rule('required|min:3|max:1024')]
    public $optionName;

    // #[Rule('nullable|sometimes|image|max:1024')]
    public $image;
    public function render()

    {
        $product_brands=Productbrand::select('name','id')->get();
        return view('livewire.select-component',['product_brands'=>$product_brands]);
    }

    public function addOption()
    {
        // $this->validate();
        // Save the option to the database 
        
        
        // $originName=$request->file('upload')->getClientOriginalName();
        //     $fileName=pathinfo($originName,PATHINFO_FILENAME);
        //     $extension=$request->file('upload')->getClientOriginalExtension();
        //     $fileName=$fileName.'__'.time().'.'.$extension;
        //     $request->file('upload')->move(public_path('textarea'),$fileName);


        // Productbrand::create([
        //     'name' => $this->optionName,
        //     'file' => $this->file->store('files', 'public'), // Store uploaded file
        // ]);

        // Clear input fields after submission
        // $this->reset(['optionName', 'image']);

        // // Close the modal after adding the option
        // $this->dispatchBrowserEvent('closeModal');
    }


}
